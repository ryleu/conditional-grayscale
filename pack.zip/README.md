# conditional-grayscale
minecraft grayscale shader that only applies when the server sends a negative gametime

# using
have your players download the pack at `https://ryleu.me/conditional-grayscale/pack.zip`

the pre-calculated hash can be found at `https://ryleu.me/conditional-grayscale/hash.txt`

whenever you want them to use the shader, send a negative game time.
