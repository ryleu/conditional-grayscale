# conditional-grayscale
minecraft grayscale shader that only applies when the server sends a negative gametime
